var gif = '<img src="https://media.giphy.com/media/A06UFEx8jxEwU/giphy.gif" alt="test screen" style="width:48px;height:48px; position: absolute; top:3px; right: 70px;"></img>';
jQuery('body').append(gif);
